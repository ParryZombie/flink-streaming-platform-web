

function skipUrl(url) {
    $(location).attr('href', url);
}

