package com.flink.streaming.web.enums;

/**
 * @author zhuhuipei
 * @Description:
 * @date 2020-09-23
 * @time 01:30
 */
public enum SysConfigEnumType {
    SYS, ALART
}
