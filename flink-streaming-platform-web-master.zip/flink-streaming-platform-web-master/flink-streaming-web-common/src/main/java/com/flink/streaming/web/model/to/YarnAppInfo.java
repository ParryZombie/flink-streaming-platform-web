package com.flink.streaming.web.model.to;

import lombok.Data;

/**
 * @author zhuhuipei
 * @Description:
 * @date 2020-08-06
 * @time 02:04
 */
@Data
public class YarnAppInfo {

    private AppListTO apps;
}
