package com.flink.streaming.web.common;

/**
 * @author zhuhuipei
 * @Description:
 * @date 2021/3/10
 * @time 21:58
 */
public class TipsConstants {

    public static String TIPS_1="请登陆服务器分别 查看flink客户端日志、web日志、集群上任务运行历史日志(如果任务提交成功)";

}
