 
 ## 2021-03-18 ~ 2021-03-19 两天 做的调研 （52份样本数量）
 
 ![图片](http://img.ccblog.cn/flink/dy-3.jpg)
 ![图片](http://img.ccblog.cn/flink/dy-1.jpg)
 ![图片](http://img.ccblog.cn/flink/dy-2.jpg)
 ![图片](http://img.ccblog.cn/flink/dy-4.jpg)
